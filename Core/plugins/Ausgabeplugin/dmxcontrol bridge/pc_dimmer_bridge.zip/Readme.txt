Dieses Plugin muss in den DMXControl-eigenen Plugin-Ordner kopiert werden (nicht den pc_dimmer_plugins-Ordner!).
Im Normalfall ist dies der Ordner "c:\Programme\DMXControl\Plugins".

Falls das Verzeichnis nicht existieren sollte, einfach Anlegen. DMXControl bindet daraufhin automatisch die vorhandenen Plugins ein.