'''''''''''''''''''''''''''''''''''''''''''''''
' An example application using the 
' Digital Enlightement USB-DMX-Interface with 
' the usbdmxsi.dll. Make shure to have the 
' usbdmx.dll and the usbdmxsi.dll located in
' the application folder.
' 
' You may use the code provided for your 
' own projects.
'
' www.digital-enlightenment.de 
''''''''''''''''''''''''''''''''''''''''''''''

Imports System.Runtime.InteropServices

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Vom Windows Form Designer generierter Code "

    Public Sub New()
        MyBase.New()

        ' Dieser Aufruf ist f�r den Windows Form-Designer erforderlich.
        InitializeComponent()

        ' Initialisierungen nach dem Aufruf InitializeComponent() hinzuf�gen

    End Sub

    ' Die Form �berschreibt den L�schvorgang der Basisklasse, um Komponenten zu bereinigen.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' F�r Windows Form-Designer erforderlich
    Private components As System.ComponentModel.IContainer

    'HINWEIS: Die folgende Prozedur ist f�r den Windows Form-Designer erforderlich
    'Sie kann mit dem Windows Form-Designer modifiziert werden.
    'Verwenden Sie nicht den Code-Editor zur Bearbeitung.
    Friend WithEvents DDMode As System.Windows.Forms.ComboBox
    Friend WithEvents btnConnect As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents dmxInputValues As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.DDMode = New System.Windows.Forms.ComboBox
        Me.btnConnect = New System.Windows.Forms.Button
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.dmxInputValues = New System.Windows.Forms.ListBox
        Me.SuspendLayout()
        '
        'DDMode
        '
        Me.DDMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DDMode.Location = New System.Drawing.Point(8, 16)
        Me.DDMode.Name = "DDMode"
        Me.DDMode.Size = New System.Drawing.Size(272, 21)
        Me.DDMode.TabIndex = 0
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(288, 16)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(72, 24)
        Me.btnConnect.TabIndex = 1
        Me.btnConnect.Text = "connect"
        '
        'Timer1
        '
        '
        'dmxInputValues
        '
        Me.dmxInputValues.BackColor = System.Drawing.SystemColors.Highlight
        Me.dmxInputValues.Dock = System.Windows.Forms.DockStyle.Right
        Me.dmxInputValues.ForeColor = System.Drawing.Color.Black
        Me.dmxInputValues.Location = New System.Drawing.Point(432, 0)
        Me.dmxInputValues.Name = "dmxInputValues"
        Me.dmxInputValues.Size = New System.Drawing.Size(48, 277)
        Me.dmxInputValues.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(480, 285)
        Me.Controls.Add(Me.dmxInputValues)
        Me.Controls.Add(Me.btnConnect)
        Me.Controls.Add(Me.DDMode)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region


    'declare USBDMXSI.dll functions
    Declare Function OpenInterface Lib "usbdmxsi.dll" Alias "OpenInterface" (ByRef Outarray As Byte, ByRef InArray As Byte, ByVal Mode As Byte) As Boolean
    Declare Function CloseInterface Lib "usbdmxsi.dll" Alias "CloseInterface" () As Boolean

    Const channelcount As Integer = 12

    Dim faders(channelcount) As System.Windows.Forms.VScrollBar
    Dim channels(channelcount) As System.Windows.Forms.NumericUpDown
    Dim connected As Boolean = False
    Public DMXOut(511) As Byte
    Public DMXIn(511) As Byte
    Private inArrPtr As GCHandle
    Private outArrPtr As GCHandle




    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'we must pin the dmx-arrays to prevent the usbdmx-dll to read
        'from the wrong location if the garbage collector decided to 
        'move the arrays in memory.
        inArrPtr = GCHandle.Alloc(DMXIn)
        outArrPtr = GCHandle.Alloc(DMXOut)

        'define interface modes
        DDMode.Items.Add("0: Do nothing - Standby")
        DDMode.Items.Add("1: DMX In -> DMX Out")
        DDMode.Items.Add("2: PC Out -> DMX Out")
        DDMode.Items.Add("3: DMX In + PC Out -> DMX Out")
        DDMode.Items.Add("4: DMX In -> PC In")
        DDMode.Items.Add("5: DMX In -> DMX Out & DMX In -> PC In")
        DDMode.Items.Add("6: PC Out -> DMX Out & DMX In -> PC In")
        DDMode.Items.Add("7: DMX In + PC Out -> DMX Out & DMX In -> PC In")
        DDMode.SelectedIndex = 0


        Dim i As Integer
        For i = 0 To channelcount
            'create a fader
            faders(i) = New System.Windows.Forms.VScrollBar
            'add it to controls-collection
            Controls.Add(faders(i))
            'do some positioning and stuff
            faders(i).SetBounds(16 + i * 51, 80, 48, 200)
            faders(i).Tag = i
            faders(i).Maximum = 255
            faders(i).Value = 255

            ' add an event handler for receiving scroll events
            AddHandler faders(i).Scroll, AddressOf Me.VScrollBar_Scroll

            'add some number-fields
            channels(i) = New System.Windows.Forms.NumericUpDown
            Controls.Add(channels(i))
            channels(i).SetBounds(16 + i * 51, 60, 48, 10)
            channels(i).Tag = i
            channels(i).Value = i
            channels(i).Maximum = 511
        Next
        'set form width 
        Width = 80 + (channelcount + 1) * 51

        'fill dmx-input-view
        For i = 0 To 511
            dmxInputValues.Items.Add(0)
        Next


    End Sub

    Private Sub VScrollBar_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs)
        'get sender object
        Dim sbar As VScrollBar = CType(sender, VScrollBar)
        Dim index As Object = sbar.Tag

        'now get the destination-dmx-channel from UpDown above scrollbar
        Dim channel As Integer = CType(channels(index), NumericUpDown).Value
        DMXOut(channel) = 255 - sbar.Value
    End Sub

    Private Sub refreshCombobox(ByRef arr As Byte(), ByVal box As ListBox)
        Dim i As Integer
        box.BeginUpdate()
        For i = 0 To Math.Min(box.Items.Count, arr.Length) - 1
            box.Items.Item(i) = arr(i)
        Next
        box.EndUpdate()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ' refreshCombobox(DMXIn, ListBox1)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        Dim res As Boolean = 0

        If connected Then
            CloseInterface()
            connected = False
            Timer1.Enabled = False
            btnConnect.Text = "connect"
            DDMode.Enabled = True
            Exit Sub
        End If

        Dim Mode As Byte = DDMode.SelectedIndex
        res = OpenInterface(DMXOut(0), DMXIn(0), Mode)

        If res Then
            btnConnect.Text = "disconnect"
            connected = True
            DDMode.Enabled = False
            Timer1.Enabled = True
        Else
            btnConnect.Text = "connect"
            DDMode.Enabled = True
            Timer1.Enabled = False
        End If
    End Sub

    Private Sub Form1_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        CloseInterface()
        inArrPtr.Free()
        outArrPtr.Free()
    End Sub
End Class
