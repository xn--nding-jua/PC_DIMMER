This is the driver disc for the Rodin1, Rodin2, RodinT, USBDMX X-Switch 
and USBDMX21 by Lighting-Solutions and Peperoni-Light.
For details please visit http://www.peperoni-light.de.

In case of trouble or problems please do not hesitate to contact 
driver@lighting-solutions.de or phone +49/40/600877-51. Thank You!

Your Driver development team.
