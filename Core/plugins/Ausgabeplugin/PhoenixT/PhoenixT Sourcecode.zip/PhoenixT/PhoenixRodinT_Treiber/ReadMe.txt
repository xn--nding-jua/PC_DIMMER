This is the Windows driver for Phoenix RodinT USB to DMX512 inteface.

To install the driver connect the interface and point the installation procedure 
to the suppied .INF file.

In case of trouble or problems please contact driver@lighting-solutions.de or 
call +49/40/600877-51. Thank You!
