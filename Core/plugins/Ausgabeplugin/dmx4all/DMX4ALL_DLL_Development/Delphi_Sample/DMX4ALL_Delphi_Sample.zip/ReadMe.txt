 DMX4ALLSample f�r Delphi
----------------------------------------------------------------

Beispiel zur Verwendung der DMX4ALL-Interface-DLL in
der Programmiersprache Delphi.


Beispielprogramm wurde von der FreeStylers(r) GmbH zur
Verf�gung gestellt.


Es besteht keine Gew�hr, dass die Software aktuell und
fehlerfrei ist. F�r Sch�den, insbesondere an Hard- und Software
als auch f�r Folgesch�den wird KEINE Haftung �bernommen.

----------------------------------------------------------------

Stand: 27.April 2007