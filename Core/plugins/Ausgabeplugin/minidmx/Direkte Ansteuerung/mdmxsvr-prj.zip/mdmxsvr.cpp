//===========================================================================
// mdmxsvr.h
// Copyright (C) 2003,2004 Mathias Dzionsko (madz@gmx.de)
//---------------------------------------------------------------------------
// �nderungen:
// 06.11.2003 - v0.1.0.0
//     Erste Testversion
// 22.03.2004 - v1.0.0.0
//     Korrektur von EXPORT_TYPE, einige Kommentare hinzugef�gt
//===========================================================================
#include <windows.h>
#pragma hdrstop
#include "mdmxsvr.h"
//===========================================================================
#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason,
    void* lpReserved)
{
    return 1;
}
//===========================================================================
// Konstanten

#define SERIALRXBUFSIZE     4096
#define SERIALTXBUFSIZE     4096
#define SERIALBAUDRATE      115200
#define SERIALTIMEOUT       50      // ms
#define SERIALRETRYCNT      3

#define MDMXBLOCKSTART      0x5a
#define MDMXCMDSEND96       0xa0
#define MDMXCMDSEND256      0xa1
#define MDMXCMDSEND512      0xa2
#define MDMXBLOCKEND        0xa5
#define MDMXCMDACK          0xc1
//===========================================================================
// Globale Variablen

int             UseUSB=0;
HANDLE          SerialPortHandle=INVALID_HANDLE_VALUE;
int             SerialMode;
HANDLE          ThreadHandle=NULL;
int             RequestThreadExit;
volatile int    DMXTransmissions;
unsigned char   DMXChannels[512];
//===========================================================================
// Interne Funktionen
//---------------------------------------------------------------------------
BOOL __fastcall SerialWrite(LPVOID buffer, DWORD bytestowrite)
{
    DWORD byteswritten;

    if (!WriteFile(SerialPortHandle, buffer, bytestowrite, &byteswritten, NULL))
        return FALSE;

    if (byteswritten!=bytestowrite) return FALSE;

    return TRUE;
}
//---------------------------------------------------------------------------
BOOL __fastcall SerialRead(LPVOID buffer, DWORD bytestoread, LPDWORD bytesread)
{
    if (!ReadFile(SerialPortHandle, buffer, bytestoread, bytesread, NULL))
        return FALSE;

    return TRUE;
}
//---------------------------------------------------------------------------
BOOL __fastcall SerialPurgeRxBuf(void)
{
    return PurgeComm(SerialPortHandle, PURGE_RXCLEAR);
}
//---------------------------------------------------------------------------
BOOL __fastcall SerialSendDMX(int mode)
{
    unsigned char buffer[512+3];
    DWORD bytesreceived;
    int numch;

    switch (mode)
    {
        case MDMX_256CH:
            numch=256;
            buffer[1]=MDMXCMDSEND256;
            break;
        case MDMX_512CH:
            numch=512;
            buffer[1]=MDMXCMDSEND512;
            break;
        default: return FALSE;
    }

    buffer[0]=MDMXBLOCKSTART;
    memcpy(&buffer[2], DMXChannels, numch);
    buffer[2+numch]=MDMXBLOCKEND;

    SerialPurgeRxBuf();
    SerialWrite(buffer, numch+3);
    SerialRead(buffer, 3, &bytesreceived);

    if (bytesreceived==3 && buffer[0]==MDMXBLOCKSTART &&
        buffer[1]==MDMXCMDACK && buffer[2]==MDMXBLOCKEND)
        return TRUE;

    return FALSE;
}
//---------------------------------------------------------------------------
#pragma argsused
DWORD WINAPI SendThread(LPVOID lpParam)
{
    while (!RequestThreadExit) {
        if (!UseUSB) {
            if (SerialSendDMX(SerialMode)) DMXTransmissions++;
        }
    }
    return 0;
}
//---------------------------------------------------------------------------
void __fastcall StopSendThread(void)
{
    DWORD exitcode;

    if (ThreadHandle!=NULL)
    {
        RequestThreadExit=1;
        do {
            GetExitCodeThread(ThreadHandle, &exitcode);
            if (exitcode==STILL_ACTIVE) Sleep(0);
        } while (exitcode==STILL_ACTIVE);

        CloseHandle(ThreadHandle);
        ThreadHandle=NULL;
    }
}
//---------------------------------------------------------------------------
BOOL __fastcall StartSendThread(void)
{
    DWORD threadid;

    if (ThreadHandle!=NULL) return TRUE;

    RequestThreadExit=0;
    DMXTransmissions=0;

    ThreadHandle=CreateThread(NULL, 0, SendThread, NULL, 0, &threadid);
    if (ThreadHandle==NULL) return FALSE;

    return TRUE;
}
//===========================================================================
// �ffentliche Funktionen
//---------------------------------------------------------------------------
int EXPORT_TYPE MDMX_OpenSerialDevice(const char *portname, int mode)
{
    DCB dcb;
    COMMTIMEOUTS timeouts;
    int retrycnt, deviceok;

    MDMX_Close();

    UseUSB=0;
    SerialMode=mode;

    SerialPortHandle=CreateFile(portname, GENERIC_READ|GENERIC_WRITE, 0, NULL,
        OPEN_EXISTING, 0, NULL);

    if (SerialPortHandle==INVALID_HANDLE_VALUE) return MDMX_ERROR_SERIALPORT;

    if (!GetCommState(SerialPortHandle, &dcb)) {
        MDMX_Close();
        return MDMX_ERROR_SERIALPORT;
    }

    dcb.BaudRate=SERIALBAUDRATE;
    dcb.fBinary=TRUE;
    dcb.fParity=FALSE;
    dcb.fOutxCtsFlow=FALSE;
    dcb.fOutxDsrFlow=FALSE;
    dcb.fDtrControl=DTR_CONTROL_ENABLE;
    dcb.fDsrSensitivity=FALSE;
    dcb.fOutX=FALSE;
    dcb.fInX=FALSE;
    dcb.fNull=FALSE;
    dcb.fRtsControl=RTS_CONTROL_ENABLE;
    dcb.fAbortOnError=FALSE;
    dcb.ByteSize=8;
    dcb.Parity=NOPARITY;
    dcb.StopBits=ONESTOPBIT;

    if (!SetCommState(SerialPortHandle, &dcb)) {
        MDMX_Close();
        return MDMX_ERROR_SERIALPORT;
    }

    timeouts.ReadIntervalTimeout=0;
    timeouts.ReadTotalTimeoutMultiplier=0;
    timeouts.ReadTotalTimeoutConstant=SERIALTIMEOUT;
    timeouts.WriteTotalTimeoutMultiplier=0;
    timeouts.WriteTotalTimeoutConstant=0;

    if (!SetCommTimeouts(SerialPortHandle, &timeouts)) {
        MDMX_Close();
        return MDMX_ERROR_SERIALPORT;
    }

    if (!SetupComm(SerialPortHandle, SERIALRXBUFSIZE, SERIALTXBUFSIZE)) {
        MDMX_Close();
        return MDMX_ERROR_SERIALPORT;
    }

    memset(DMXChannels, 0, 512);
    for (retrycnt=0, deviceok=0; (retrycnt<SERIALRETRYCNT) && !deviceok;
        retrycnt++) deviceok=SerialSendDMX(MDMX_256CH);

    if (!deviceok) {
        MDMX_Close();
        return MDMX_ERROR_DEVICENOTFOUND;
    }

    if (!StartSendThread()) {
        MDMX_Close();
        return MDMX_ERROR_CREATETHREAD;
    }

    return MDMX_OK;
}
//---------------------------------------------------------------------------
int EXPORT_TYPE MDMX_SetChannel(int channel, int value)
{
    if (channel<0 || channel>511 || value<0 || value>255)
        return MDMX_ERROR_PARAMOUTOFRANGE;
    DMXChannels[channel]=value;
    return MDMX_OK;
}
//---------------------------------------------------------------------------
int EXPORT_TYPE MDMX_GetDMXTransmissions(void)
{
    int counter=DMXTransmissions;
    DMXTransmissions=0;
    return counter;
}
//---------------------------------------------------------------------------
void EXPORT_TYPE MDMX_Close(void)
{
    StopSendThread();
    if (!UseUSB) {
        if (SerialPortHandle!=INVALID_HANDLE_VALUE) {
            CloseHandle(SerialPortHandle);
            SerialPortHandle=INVALID_HANDLE_VALUE;
        }
    }
}
//===========================================================================

